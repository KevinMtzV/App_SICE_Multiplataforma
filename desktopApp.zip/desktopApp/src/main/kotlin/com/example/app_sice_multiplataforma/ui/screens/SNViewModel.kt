package com.example.app_sice_multiplataforma.ui.screens

import com.example.app_sice_multiplataforma.data.LocalCache
import com.example.app_sice_multiplataforma.model.*
import com.example.app_sice_multiplataforma.network.SicenetService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.net.InetSocketAddress
import java.net.Socket

// --- UI State ---

sealed interface SNUiState {
    data class Success(
        val data: ProfileStudent,
        val kardex: List<KardexItem> = emptyList(),
        val califUnidades: List<CalificacionParcial> = emptyList(),
        val califFinales: List<CalificacionFinal> = emptyList(),
        val cargaAcademica: List<MateriaCarga> = emptyList(),
        val esOffline: Boolean = false,
        val ultimaSincro: String = ""
    ) : SNUiState

    object Error : SNUiState
    object Loading : SNUiState
    object Idle : SNUiState
}

// --- ViewModel ---

class SNViewModel {

    private val service = SicenetService()
    private val cache = LocalCache()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val _uiState = MutableStateFlow<SNUiState>(SNUiState.Idle)
    val uiState: StateFlow<SNUiState> = _uiState

    fun hayInternet(): Boolean {
        return try {
            Socket().use { socket ->
                // Usamos la misma URL que el servicio
                socket.connect(InetSocketAddress("sicenet.surguanajuato.tecnm.mx", 443), 3000)
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    fun loginYConsultarPerfil(matricula: String, contrasenia: String, tipo: String = "ALUMNO") {
        _uiState.value = SNUiState.Loading
        scope.launch {
            // Modo offline primero si no hay red
            if (!hayInternet()) {
                val perfilLocal = cache.getPerfil()
                if (perfilLocal != null) {
                    _uiState.value = SNUiState.Success(
                        data = perfilLocal,
                        kardex = cache.getKardex(),
                        cargaAcademica = cache.getCarga(),
                        califUnidades = cache.getParciales(),
                        califFinales = cache.getFinales(),
                        esOffline = true,
                        ultimaSincro = cache.getUltimaSincro()
                    )
                } else {
                    _uiState.value = SNUiState.Error
                }
                return@launch
            }

            // Reintentos — igual que LoginWorker en Android
            val maxIntentos = 3
            var intento = 0
            var loginOk = false

            while (intento < maxIntentos && !loginOk) {
                try {
                    loginOk = service.acceso(matricula, contrasenia, tipo)
                    if (!loginOk) {
                        // Respuesta clara de credenciales incorrectas — no reintentar
                        _uiState.value = SNUiState.Error
                        return@launch
                    }
                } catch (e: Exception) {
                    intento++
                    if (intento < maxIntentos) delay(2000)
                }
            }

            if (!loginOk) {
                _uiState.value = SNUiState.Error
                return@launch
            }

            // Login OK — obtener perfil (las cookies ya están en el jar)
            val perfil = try {
                service.getPerfil(matricula, contrasenia)
            } catch (e: Exception) {
                null
            }

            if (perfil == null || perfil.matricula.isBlank()) {
                _uiState.value = SNUiState.Error
                return@launch
            }

            cache.insertPerfil(perfil)

            // Descargar todo en paralelo
            val kardexDef = async { runCatching { service.getKardex() }.getOrDefault(emptyList()) }
            val cargaDef = async { runCatching { service.getCargaAcademica() }.getOrDefault(emptyList()) }
            val parcialesDef = async { runCatching { service.getCalifUnidades() }.getOrDefault(emptyList()) }
            val finalesDef = async { runCatching { service.getCalifFinales() }.getOrDefault(emptyList()) }

            val kardex = kardexDef.await()
            val carga = cargaDef.await()
            val parciales = parcialesDef.await()
            val finales = finalesDef.await()

            if (kardex.isNotEmpty()) cache.insertKardex(kardex)
            if (carga.isNotEmpty()) cache.insertCarga(carga)
            if (parciales.isNotEmpty()) cache.insertParciales(parciales)
            if (finales.isNotEmpty()) cache.insertFinales(finales)

            _uiState.value = SNUiState.Success(
                data = perfil,
                kardex = kardex,
                cargaAcademica = carga,
                califUnidades = parciales,
                califFinales = finales,
                esOffline = false,
                ultimaSincro = cache.getUltimaSincro()
            )
        }
    }

    fun consultarKardex() {
        val current = _uiState.value as? SNUiState.Success ?: return
        scope.launch {
            if (hayInternet()) {
                try {
                    val lista = service.getKardex()
                    cache.insertKardex(lista)
                    _uiState.value = current.copy(kardex = lista, esOffline = false)
                } catch (e: Exception) { }
            } else {
                _uiState.value = current.copy(
                    kardex = cache.getKardex(),
                    esOffline = true,
                    ultimaSincro = cache.getUltimaSincro()
                )
            }
        }
    }

    fun consultarCargaAcademica() {
        val current = _uiState.value as? SNUiState.Success ?: return
        scope.launch {
            if (hayInternet()) {
                try {
                    val lista = service.getCargaAcademica()
                    cache.insertCarga(lista)
                    _uiState.value = current.copy(cargaAcademica = lista, esOffline = false)
                } catch (e: Exception) { }
            } else {
                _uiState.value = current.copy(
                    cargaAcademica = cache.getCarga(),
                    esOffline = true,
                    ultimaSincro = cache.getUltimaSincro()
                )
            }
        }
    }

    fun consultarCalificacionesUnidades() {
        val current = _uiState.value as? SNUiState.Success ?: return
        scope.launch {
            if (hayInternet()) {
                try {
                    val lista = service.getCalifUnidades()
                    cache.insertParciales(lista)
                    _uiState.value = current.copy(califUnidades = lista, esOffline = false)
                } catch (e: Exception) { }
            } else {
                _uiState.value = current.copy(
                    califUnidades = cache.getParciales(),
                    esOffline = true,
                    ultimaSincro = cache.getUltimaSincro()
                )
            }
        }
    }

    fun consultarCalificacionesFinales() {
        val current = _uiState.value as? SNUiState.Success ?: return
        scope.launch {
            if (hayInternet()) {
                try {
                    val lista = service.getCalifFinales()
                    if (lista.isNotEmpty()) cache.insertFinales(lista)
                    _uiState.value = current.copy(califFinales = lista, esOffline = false)
                } catch (e: Exception) { }
            } else {
                _uiState.value = current.copy(
                    califFinales = cache.getFinales(),
                    esOffline = true,
                    ultimaSincro = cache.getUltimaSincro()
                )
            }
        }
    }

    fun logout() {
        service.clearCookies()
        _uiState.value = SNUiState.Idle
    }

    fun onDispose() {
        scope.cancel()
    }
}
