package com.example.app_sice_multiplataforma.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.app_sice_multiplataforma.ui.screens.*

// Rutas de navegación
enum class Screen {
    Login, Profile, Carga, Kardex, Parciales, Finales
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSicenet(viewModel: SNViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    var currentScreen by remember { mutableStateOf(Screen.Login) }
    var drawerOpen by remember { mutableStateOf(false) }

    // Auto-navegar al perfil cuando el login sea exitoso
    LaunchedEffect(uiState) {
        if (uiState is SNUiState.Success && currentScreen == Screen.Login) {
            currentScreen = Screen.Profile
        }
    }

    if (uiState is SNUiState.Success) {
        val successState = uiState as SNUiState.Success

        // Layout de dos columnas (rail + contenido)
        Row(modifier = Modifier.fillMaxSize()) {

            // --- NAVIGATION RAIL (lado izquierdo) ---
            NavigationRailPanel(
                currentScreen = currentScreen,
                student = successState,
                onNavigate = { screen ->
                    currentScreen = screen
                    when (screen) {
                        Screen.Kardex -> viewModel.consultarKardex()
                        Screen.Carga -> viewModel.consultarCargaAcademica()
                        Screen.Parciales -> viewModel.consultarCalificacionesUnidades()
                        Screen.Finales -> viewModel.consultarCalificacionesFinales()
                        else -> {}
                    }
                },
                onLogout = {
                    viewModel.logout()
                    currentScreen = Screen.Login
                }
            )

            // --- CONTENIDO PRINCIPAL ---
            Column(modifier = Modifier.weight(1f).fillMaxHeight()) {

                // Banner de modo offline visible en todas las pantallas
                if (successState.esOffline && successState.ultimaSincro.isNotBlank()) {
                    Surface(
                        color = Color(0xFFFFF3E0),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CloudOff, null, tint = Color(0xFFE65100), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Sin internet. Datos guardados el: ${successState.ultimaSincro}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFE65100),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else if (successState.ultimaSincro.isNotBlank()) {
                    Surface(
                        color = Color(0xFFE8F5E9),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CloudDone, null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Actualizado: ${successState.ultimaSincro}",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF2E7D32)
                            )
                        }
                    }
                }

                // Contenido de la pantalla activa
                when (currentScreen) {
                    Screen.Profile -> ProfileScreen(successState.data, modifier = Modifier.weight(1f))
                    Screen.Kardex -> KardexScreen(successState.kardex, modifier = Modifier.weight(1f))
                    Screen.Carga -> CargaAcademicaScreen(successState.cargaAcademica, modifier = Modifier.weight(1f))
                    Screen.Parciales -> CalificacionesScreen(successState.califUnidades, modifier = Modifier.weight(1f))
                    Screen.Finales -> FinalesScreen(successState.califFinales, modifier = Modifier.weight(1f))
                    Screen.Login -> {} // No debería llegar aquí en estado Success
                }
            }
        }
    } else {
        // Pantalla de login / carga / error
        HomeScreen(
            snUiState = uiState,
            onLoginClick = { m, p, t -> viewModel.loginYConsultarPerfil(m, p, t) },
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun NavigationRailPanel(
    currentScreen: Screen,
    student: SNUiState.Success,
    onNavigate: (Screen) -> Unit,
    onLogout: () -> Unit
) {
    val primaryColor = Color(0xFF4A2C5D)

    NavigationRail(
        modifier = Modifier.fillMaxHeight().width(200.dp),
        containerColor = primaryColor,
        header = {
            // Header con nombre del estudiante
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(primaryColor, primaryColor.copy(alpha = 0.85f))
                        )
                    )
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    modifier = Modifier.size(52.dp),
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.2f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.padding(10.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = student.data.nombre.split(" ").firstOrNull() ?: "Estudiante",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = student.data.matricula,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.7f)
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "SICENET",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.5f),
                    fontWeight = FontWeight.Black,
                    letterSpacing = androidx.compose.ui.unit.TextUnit(2f, androidx.compose.ui.unit.TextUnitType.Sp)
                )
            }
        }
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        RailSection(title = "ACADÉMICO")
        RailItem(label = "Mi Perfil", icon = Icons.Default.AccountCircle, selected = currentScreen == Screen.Profile) { onNavigate(Screen.Profile) }
        RailItem(label = "Horario/Carga", icon = Icons.Default.DateRange, selected = currentScreen == Screen.Carga) { onNavigate(Screen.Carga) }
        RailItem(label = "Kardex", icon = Icons.Default.HistoryEdu, selected = currentScreen == Screen.Kardex) { onNavigate(Screen.Kardex) }

        Divider(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), color = Color.White.copy(alpha = 0.2f))

        RailSection(title = "EVALUACIONES")
        RailItem(label = "Parciales", icon = Icons.Default.Spellcheck, selected = currentScreen == Screen.Parciales) { onNavigate(Screen.Parciales) }
        RailItem(label = "Finales", icon = Icons.Default.AssignmentTurnedIn, selected = currentScreen == Screen.Finales) { onNavigate(Screen.Finales) }

        Spacer(modifier = Modifier.weight(1f))

        // Cerrar sesión
        NavigationRailItem(
            selected = false,
            onClick = onLogout,
            icon = { Icon(Icons.Default.Logout, null, tint = Color.White.copy(alpha = 0.7f)) },
            label = { Text("Salir", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelSmall) },
            colors = NavigationRailItemDefaults.colors(
                indicatorColor = Color.White.copy(alpha = 0.15f)
            )
        )

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun RailSection(title: String) {
    Text(
        text = title,
        modifier = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp),
        style = MaterialTheme.typography.labelSmall,
        color = Color.White.copy(alpha = 0.5f),
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun RailItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    NavigationRailItem(
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, contentDescription = null, tint = if (selected) Color(0xFF4A2C5D) else Color.White) },
        label = {
            Text(
                label,
                color = if (selected) Color(0xFF4A2C5D) else Color.White.copy(alpha = 0.85f),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
            )
        },
        colors = NavigationRailItemDefaults.colors(
            selectedIconColor = Color(0xFF4A2C5D),
            indicatorColor = Color.White
        )
    )
}
