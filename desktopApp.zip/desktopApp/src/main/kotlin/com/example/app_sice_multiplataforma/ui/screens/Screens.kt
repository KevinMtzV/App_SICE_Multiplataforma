package com.example.app_sice_multiplataforma.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.app_sice_multiplataforma.model.CalificacionFinal
import com.example.app_sice_multiplataforma.model.CalificacionParcial
import com.example.app_sice_multiplataforma.model.MateriaCarga

// ============================================================
// CARGA ACADÉMICA
// ============================================================

@Composable
fun CargaAcademicaScreen(
    carga: List<MateriaCarga>,
    modifier: Modifier = Modifier
) {
    val dias = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes")
    var selectedTabIndex by remember { mutableIntStateOf(0) }

    Column(modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.White,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.Indicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    height = 4.dp,
                    color = MaterialTheme.colorScheme.tertiaryContainer
                )
            },
            divider = {}
        ) {
            dias.forEachIndexed { index, dia ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Text(
                            text = dia.take(3).uppercase(),
                            fontWeight = if (selectedTabIndex == index) FontWeight.Black else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                    }
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .padding(bottom = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                color = Color.White.copy(alpha = 0.2f),
                shape = RoundedCornerShape(20.dp)
            ) {
                Text(
                    text = "Horario de ${dias[selectedTabIndex]}",
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        val materiasFiltradas = when (selectedTabIndex) {
            0 -> carga.filter { it.lunes.isNotBlank() }
            1 -> carga.filter { it.martes.isNotBlank() }
            2 -> carga.filter { it.miercoles.isNotBlank() }
            3 -> carga.filter { it.jueves.isNotBlank() }
            4 -> carga.filter { it.viernes.isNotBlank() }
            else -> emptyList()
        }

        if (materiasFiltradas.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Schedule, null, modifier = Modifier.size(64.dp), tint = Color.LightGray)
                    Text("No hay clases programadas", color = Color.Gray, style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(materiasFiltradas) { materia ->
                    CargaCardDesktop(materia, selectedTabIndex)
                }
            }
        }
    }
}

@Composable
fun CargaCardDesktop(materia: MateriaCarga, diaSeleccionado: Int) {
    val infoDelDia = when (diaSeleccionado) {
        0 -> materia.lunes
        1 -> materia.martes
        2 -> materia.miercoles
        3 -> materia.jueves
        4 -> materia.viernes
        else -> ""
    }

    val horario = infoDelDia.substringBefore(" Aula:").trim()
    val aula = if (infoDelDia.contains("Aula:")) infoDelDia.substringAfter("Aula: ").trim() else "N/A"

    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Column(modifier = Modifier.width(70.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = horario.take(5),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Box(
                modifier = Modifier.width(2.dp).height(60.dp)
                    .background(
                        Brush.verticalGradient(listOf(MaterialTheme.colorScheme.primary, Color.Transparent))
                    )
            )
        }

        Card(
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = materia.materia,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = materia.docente, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
                Spacer(modifier = Modifier.height(12.dp))
                Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(8.dp)) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.LocationOn, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("AULA: $aula", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                }
            }
        }
    }
}

// ============================================================
// CALIFICACIONES PARCIALES
// ============================================================

@Composable
fun CalificacionesScreen(
    parciales: List<CalificacionParcial>,
    modifier: Modifier = Modifier
) {
    if (parciales.isEmpty()) {
        EmptyDataScreen("Sin calificaciones parciales registradas", modifier)
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(parciales) { calif ->
            ParcialCard(calif)
        }
    }
}

@Composable
fun ParcialCard(calif: CalificacionParcial) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = calif.materia,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF4A2C5D)
            )
            Spacer(modifier = Modifier.height(12.dp))

            val periodos = listOf(
                "U1" to calif.p1, "U2" to calif.p2, "U3" to calif.p3,
                "U4" to calif.p4, "U5" to calif.p5, "U6" to calif.p6,
                "U7" to calif.p7, "U8" to calif.p8, "U9" to calif.p9,
                "U10" to calif.p10, "U11" to calif.p11, "U12" to calif.p12, "U13" to calif.p13
            ).filter { it.second != null && it.second!!.isNotBlank() }

            if (periodos.isEmpty()) {
                Text("Sin calificaciones registradas", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    periodos.forEach { (label, valor) ->
                        val calNum = valor?.toDoubleOrNull() ?: 0.0
                        val color = when {
                            calNum >= 90 -> Color(0xFF2E7D32)
                            calNum >= 70 -> Color(0xFF1565C0)
                            else -> Color(0xFFC62828)
                        }
                        Surface(
                            color = color.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(label, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                Text(valor ?: "-", fontWeight = FontWeight.Bold, color = color, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================
// CALIFICACIONES FINALES
// ============================================================

@Composable
fun FinalesScreen(
    finales: List<CalificacionFinal>,
    modifier: Modifier = Modifier
) {
    if (finales.isEmpty()) {
        EmptyDataScreen("Sin calificaciones finales registradas", modifier)
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(finales) { final ->
            FinalCard(final)
        }
    }
}

@Composable
fun FinalCard(final: CalificacionFinal) {
    val calNum = final.calificacion.toDoubleOrNull() ?: 0.0
    val aprobado = calNum >= 70
    val color = if (aprobado) Color(0xFF2E7D32) else Color(0xFFC62828)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (aprobado) Icons.Default.CheckCircle else Icons.Default.Cancel,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(final.materia, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                if (final.acreditacion.isNotBlank()) {
                    Text(final.acreditacion, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
            Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(8.dp)) {
                Text(
                    text = final.calificacion.ifBlank { "–" },
                    color = color,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }
        }
    }
}

// ============================================================
// EMPTY STATE
// ============================================================

@Composable
fun EmptyDataScreen(mensaje: String, modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Inbox, null, modifier = Modifier.size(64.dp), tint = Color.LightGray)
            Spacer(modifier = Modifier.height(16.dp))
            Text(mensaje, color = Color.Gray, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
