package com.example.app_sice_multiplataforma.network

import com.example.app_sice_multiplataforma.model.*
import kotlinx.serialization.json.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.CookieManager
import java.net.CookiePolicy
import java.util.concurrent.TimeUnit

// --- SOAP BODIES ---

private val bodyAcceso = """
    <?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Body>
        <accesoLogin xmlns="http://tempuri.org/">
          <strMatricula>%s</strMatricula>
          <strContrasenia>%s</strContrasenia>   
          <tipoUsuario>%s</tipoUsuario> 
        </accesoLogin>
      </soap:Body>
    </soap:Envelope>
""".trimIndent()

private val bodyAlumno = """
    <?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Body>
        <getAlumnoAcademicoWithLineamiento xmlns="http://tempuri.org/">
          <strMatricula>%s</strMatricula>
          <strContrasenia>%s</strContrasenia>
        </getAlumnoAcademicoWithLineamiento>
      </soap:Body>
    </soap:Envelope>
""".trimIndent()

private val bodyKardex = """
    <?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Body>
        <getAllKardexConPromedioByAlumno xmlns="http://tempuri.org/">
          <aluLineamiento>%s</aluLineamiento>
        </getAllKardexConPromedioByAlumno>
      </soap:Body>
    </soap:Envelope>
""".trimIndent()

private val bodyVacio = """
    <?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Body>
        <getCalifUnidadesByAlumno xmlns="http://tempuri.org/" />
      </soap:Body>
    </soap:Envelope>
""".trimIndent()

private val bodyCalifFinales = """
    <?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Body>
        <getAllCalifFinalByAlumnos xmlns="http://tempuri.org/">
          <bytModEducativo>%d</bytModEducativo>
        </getAllCalifFinalByAlumnos>
      </soap:Body>
    </soap:Envelope>
""".trimIndent()

private val bodyCargaAcademica = """
    <?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
      <soap:Body>
        <getCargaAcademicaByAlumno xmlns="http://tempuri.org/" />
      </soap:Body>
    </soap:Envelope>
""".trimIndent()

// --- CLIENTE HTTP ---

class SicenetService {

    private val cookieManager = CookieManager().also {
        it.setCookiePolicy(CookiePolicy.ACCEPT_ALL)
    }

    private val client = OkHttpClient.Builder()
        .cookieJar(JavaNetCookieJar(cookieManager))
        .connectTimeout(120, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    // URL correcta — igual que la app Android
    private val baseUrl = "https://sicenet.surguanajuato.tecnm.mx"
    private val xmlMediaType = "text/xml; charset=utf-8".toMediaType()
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    // --- Helpers ---

    private fun post(soapAction: String, body: String): String {
        val request = Request.Builder()
            .url("$baseUrl/ws/wsalumnos.asmx")
            .addHeader("Content-Type", "text/xml; charset=utf-8")
            .addHeader("SOAPAction", "\"http://tempuri.org/$soapAction\"")
            .post(body.toRequestBody(xmlMediaType))
            .build()
        return client.newCall(request).execute().use { it.body!!.string() }
    }

    private fun limpiarJson(xml: String): String {
        return xml
            .replace("&quot;", "\"")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("\\\"", "\"")
            .trim()
    }

    private fun extraerJson(xml: String, inicio: String, fin: String): String {
        val startIndex = xml.indexOf(inicio)
        val endIndex = xml.lastIndexOf(fin)
        return if (startIndex != -1 && endIndex != -1) {
            xml.substring(startIndex, endIndex + 1)
        } else {
            if (inicio == "[") "[]" else "{}"
        }
    }

    /**
     * Extrae el texto dentro de un tag XML.
     * Ej: <accesoLoginResult>true</accesoLoginResult> → "true"
     */
    private fun extraerTextoXml(xml: String, tag: String): String? {
        val open = "<$tag>"
        val close = "</$tag>"
        val start = xml.indexOf(open)
        val end = xml.indexOf(close)
        return if (start != -1 && end != -1) {
            xml.substring(start + open.length, end).trim()
        } else null
    }

    private inline fun <reified T> parseList(xml: String): List<T> {
        return try {
            val jsonStr = limpiarJson(extraerJson(xml, "[", "]"))
            if (jsonStr == "[]" || !jsonStr.contains("{")) return emptyList()
            val arr = json.parseToJsonElement(jsonStr).jsonArray
            arr.map { json.decodeFromJsonElement(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private inline fun <reified T> parseObject(xml: String): T? {
        return try {
            val jsonStr = limpiarJson(extraerJson(xml, "{", "}"))
            if (!jsonStr.contains("{")) return null
            json.decodeFromString<T>(jsonStr)
        } catch (e: Exception) {
            null
        }
    }

    // --- API pública ---

    /**
     * Hace login y valida la cookie de sesión obtenida.
     * La respuesta SOAP contiene <accesoLoginResult>true</accesoLoginResult>.
     * Si el servidor responde con "true" en ese campo, el login fue exitoso
     * y las cookies de sesión ya quedaron guardadas en el CookieJar.
     */
    suspend fun acceso(matricula: String, contrasenia: String, tipo: String = "ALUMNO"): Boolean {
        return try {
            val response = post("accesoLogin", bodyAcceso.format(matricula, contrasenia, tipo))

            // El servidor devuelve: <accesoLoginResult>true</accesoLoginResult>
            val resultTag = extraerTextoXml(response, "accesoLoginResult")
            if (resultTag != null) {
                return resultTag.equals("true", ignoreCase = true)
            }

            // Fallback: buscar "true" en cualquier parte de la respuesta (sin incluir el DOCTYPE)
            // pero excluir casos como "false" o errores
            val sinXml = response.replace(Regex("<[^>]+>"), " ").trim()
            sinXml.split(Regex("\\s+")).any { it.equals("true", ignoreCase = true) }
        } catch (e: Exception) {
            false
        }
    }

    suspend fun getPerfil(matricula: String, contrasenia: String): ProfileStudent? {
        return try {
            val response = post("getAlumnoAcademicoWithLineamiento", bodyAlumno.format(matricula, contrasenia))
            parseObject<ProfileStudent>(response)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun getKardex(lineamiento: String = "1"): List<KardexItem> {
        return try {
            val response = post("getAllKardexConPromedioByAlumno", bodyKardex.format(lineamiento))
            parseList(response)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getCalifUnidades(): List<CalificacionParcial> {
        return try {
            val response = post("getCalifUnidadesByAlumno", bodyVacio)
            parseList(response)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getCalifFinales(modoEducativo: Int = 1): List<CalificacionFinal> {
        return try {
            val response = post("getAllCalifFinalByAlumnos", bodyCalifFinales.format(modoEducativo))
            parseList(response)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun getCargaAcademica(): List<MateriaCarga> {
        return try {
            val response = post("getCargaAcademicaByAlumno", bodyCargaAcademica)
            parseList(response)
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun clearCookies() {
        cookieManager.cookieStore.removeAll()
    }
}
